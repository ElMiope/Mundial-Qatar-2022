<?php
require_once("include/dbcommon.php");
require_once('classes/menupage.php');


?>