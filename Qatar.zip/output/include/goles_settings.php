<?php
$tdatagoles = array();
$tdatagoles[".searchableFields"] = array();
$tdatagoles[".ShortName"] = "goles";
$tdatagoles[".OwnerID"] = "";
$tdatagoles[".OriginalTable"] = "goles";


$tdatagoles[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatagoles[".originalPagesByType"] = $tdatagoles[".pagesByType"];
$tdatagoles[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatagoles[".originalPages"] = $tdatagoles[".pages"];
$tdatagoles[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatagoles[".originalDefaultPages"] = $tdatagoles[".defaultPages"];

//	field labels
$fieldLabelsgoles = array();
$fieldToolTipsgoles = array();
$pageTitlesgoles = array();
$placeHoldersgoles = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsgoles["English"] = array();
	$fieldToolTipsgoles["English"] = array();
	$placeHoldersgoles["English"] = array();
	$pageTitlesgoles["English"] = array();
	$fieldLabelsgoles["English"]["ID"] = "ID";
	$fieldToolTipsgoles["English"]["ID"] = "";
	$placeHoldersgoles["English"]["ID"] = "";
	$fieldLabelsgoles["English"]["Goleador"] = "Goleador";
	$fieldToolTipsgoles["English"]["Goleador"] = "";
	$placeHoldersgoles["English"]["Goleador"] = "";
	$fieldLabelsgoles["English"]["Minuto"] = "Minuto";
	$fieldToolTipsgoles["English"]["Minuto"] = "";
	$placeHoldersgoles["English"]["Minuto"] = "";
	$fieldLabelsgoles["English"]["Tipo_de_Gol"] = "Tipo de Gol";
	$fieldToolTipsgoles["English"]["Tipo_de_Gol"] = "";
	$placeHoldersgoles["English"]["Tipo_de_Gol"] = "";
	if (count($fieldToolTipsgoles["English"]))
		$tdatagoles[".isUseToolTips"] = true;
}


	$tdatagoles[".NCSearch"] = true;



$tdatagoles[".shortTableName"] = "goles";
$tdatagoles[".nSecOptions"] = 0;

$tdatagoles[".mainTableOwnerID"] = "";
$tdatagoles[".entityType"] = 0;
$tdatagoles[".connId"] = "qatar_at_localhost";


$tdatagoles[".strOriginalTableName"] = "goles";

	



$tdatagoles[".showAddInPopup"] = false;

$tdatagoles[".showEditInPopup"] = false;

$tdatagoles[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatagoles[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatagoles[".listAjax"] = false;
//	temporary
$tdatagoles[".listAjax"] = false;

	$tdatagoles[".audit"] = false;

	$tdatagoles[".locking"] = false;


$pages = $tdatagoles[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatagoles[".edit"] = true;
	$tdatagoles[".afterEditAction"] = 1;
	$tdatagoles[".closePopupAfterEdit"] = 1;
	$tdatagoles[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatagoles[".add"] = true;
$tdatagoles[".afterAddAction"] = 1;
$tdatagoles[".closePopupAfterAdd"] = 1;
$tdatagoles[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatagoles[".list"] = true;
}



$tdatagoles[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatagoles[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatagoles[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatagoles[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatagoles[".printFriendly"] = true;
}



$tdatagoles[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatagoles[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatagoles[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatagoles[".isUseAjaxSuggest"] = true;

$tdatagoles[".rowHighlite"] = true;





$tdatagoles[".ajaxCodeSnippetAdded"] = false;

$tdatagoles[".buttonsAdded"] = false;

$tdatagoles[".addPageEvents"] = false;

// use timepicker for search panel
$tdatagoles[".isUseTimeForSearch"] = false;


$tdatagoles[".badgeColor"] = "DB7093";


$tdatagoles[".allSearchFields"] = array();
$tdatagoles[".filterFields"] = array();
$tdatagoles[".requiredSearchFields"] = array();

$tdatagoles[".googleLikeFields"] = array();
$tdatagoles[".googleLikeFields"][] = "ID";
$tdatagoles[".googleLikeFields"][] = "Goleador";
$tdatagoles[".googleLikeFields"][] = "Minuto";
$tdatagoles[".googleLikeFields"][] = "Tipo de Gol";



$tdatagoles[".tableType"] = "list";

$tdatagoles[".printerPageOrientation"] = 0;
$tdatagoles[".nPrinterPageScale"] = 100;

$tdatagoles[".nPrinterSplitRecords"] = 40;

$tdatagoles[".geocodingEnabled"] = false;










$tdatagoles[".pageSize"] = 20;

$tdatagoles[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatagoles[".strOrderBy"] = $tstrOrderBy;

$tdatagoles[".orderindexes"] = array();


$tdatagoles[".sqlHead"] = "SELECT ID,  	Goleador,  	Minuto,  	`Tipo de Gol`";
$tdatagoles[".sqlFrom"] = "FROM goles";
$tdatagoles[".sqlWhereExpr"] = "";
$tdatagoles[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatagoles[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatagoles[".arrGroupsPerPage"] = $arrGPP;

$tdatagoles[".highlightSearchResults"] = true;

$tableKeysgoles = array();
$tableKeysgoles[] = "ID";
$tdatagoles[".Keys"] = $tableKeysgoles;


$tdatagoles[".hideMobileList"] = array();




//	ID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID";
	$fdata["GoodName"] = "ID";
	$fdata["ownerTable"] = "goles";
	$fdata["Label"] = GetFieldLabel("goles","ID");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "ID";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagoles["ID"] = $fdata;
		$tdatagoles[".searchableFields"][] = "ID";
//	Goleador
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "Goleador";
	$fdata["GoodName"] = "Goleador";
	$fdata["ownerTable"] = "goles";
	$fdata["Label"] = GetFieldLabel("goles","Goleador");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Goleador";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Goleador";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "jugadores";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Nombre y apellido";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Nombre y apellido";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagoles["Goleador"] = $fdata;
		$tdatagoles[".searchableFields"][] = "Goleador";
//	Minuto
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Minuto";
	$fdata["GoodName"] = "Minuto";
	$fdata["ownerTable"] = "goles";
	$fdata["Label"] = GetFieldLabel("goles","Minuto");
	$fdata["FieldType"] = 134;

	
	
	
			

		$fdata["strField"] = "Minuto";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Minuto";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Time");

	
	
	
	
	
	
	
	
	
	
	
		
		$vdata["timeFormatData"] = array(
		"showSeconds" => false,
		"showDaysInTotals" => false,
		"timeFormat" => 0
	);
	$vdata["timeFormatData"]["showSeconds"] = true;
	$vdata["timeFormatData"]["showDaysInTotals"] = true;

		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Time");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
				$hours = 24;
	$edata["FormatTimeAttrs"] = array("useTimePicker" => 0,
									  "hours" => $hours,
									  "minutes" => 1,
									  "showSeconds" => 0);

	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagoles["Minuto"] = $fdata;
		$tdatagoles[".searchableFields"][] = "Minuto";
//	Tipo de Gol
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Tipo de Gol";
	$fdata["GoodName"] = "Tipo_de_Gol";
	$fdata["ownerTable"] = "goles";
	$fdata["Label"] = GetFieldLabel("goles","Tipo_de_Gol");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Tipo de Gol";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Tipo de Gol`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "tipos de goles";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Tipo de Gol";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Tipo de Gol";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagoles["Tipo de Gol"] = $fdata;
		$tdatagoles[".searchableFields"][] = "Tipo de Gol";


$tables_data["goles"]=&$tdatagoles;
$field_labels["goles"] = &$fieldLabelsgoles;
$fieldToolTips["goles"] = &$fieldToolTipsgoles;
$placeHolders["goles"] = &$placeHoldersgoles;
$page_titles["goles"] = &$pageTitlesgoles;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["goles"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["goles"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_goles()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "ID,  	Goleador,  	Minuto,  	`Tipo de Gol`";
$proto0["m_strFrom"] = "FROM goles";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "ID",
	"m_strTable" => "goles",
	"m_srcTableName" => "goles"
));

$proto6["m_sql"] = "ID";
$proto6["m_srcTableName"] = "goles";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "Goleador",
	"m_strTable" => "goles",
	"m_srcTableName" => "goles"
));

$proto8["m_sql"] = "Goleador";
$proto8["m_srcTableName"] = "goles";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Minuto",
	"m_strTable" => "goles",
	"m_srcTableName" => "goles"
));

$proto10["m_sql"] = "Minuto";
$proto10["m_srcTableName"] = "goles";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Tipo de Gol",
	"m_strTable" => "goles",
	"m_srcTableName" => "goles"
));

$proto12["m_sql"] = "`Tipo de Gol`";
$proto12["m_srcTableName"] = "goles";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto14=array();
$proto14["m_link"] = "SQLL_MAIN";
			$proto15=array();
$proto15["m_strName"] = "goles";
$proto15["m_srcTableName"] = "goles";
$proto15["m_columns"] = array();
$proto15["m_columns"][] = "ID";
$proto15["m_columns"][] = "Goleador";
$proto15["m_columns"][] = "Minuto";
$proto15["m_columns"][] = "Tipo de Gol";
$obj = new SQLTable($proto15);

$proto14["m_table"] = $obj;
$proto14["m_sql"] = "goles";
$proto14["m_alias"] = "";
$proto14["m_srcTableName"] = "goles";
$proto16=array();
$proto16["m_sql"] = "";
$proto16["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto16["m_column"]=$obj;
$proto16["m_contained"] = array();
$proto16["m_strCase"] = "";
$proto16["m_havingmode"] = false;
$proto16["m_inBrackets"] = false;
$proto16["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto16);

$proto14["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto14);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="goles";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_goles = createSqlQuery_goles();


	
		;

				

$tdatagoles[".sqlquery"] = $queryData_goles;



$tableEvents["goles"] = new eventsBase;
$tdatagoles[".hasEvents"] = false;

?>