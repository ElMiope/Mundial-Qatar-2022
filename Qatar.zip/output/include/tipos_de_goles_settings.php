<?php
$tdatatipos_de_goles = array();
$tdatatipos_de_goles[".searchableFields"] = array();
$tdatatipos_de_goles[".ShortName"] = "tipos_de_goles";
$tdatatipos_de_goles[".OwnerID"] = "";
$tdatatipos_de_goles[".OriginalTable"] = "tipos de goles";


$tdatatipos_de_goles[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatatipos_de_goles[".originalPagesByType"] = $tdatatipos_de_goles[".pagesByType"];
$tdatatipos_de_goles[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatatipos_de_goles[".originalPages"] = $tdatatipos_de_goles[".pages"];
$tdatatipos_de_goles[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatatipos_de_goles[".originalDefaultPages"] = $tdatatipos_de_goles[".defaultPages"];

//	field labels
$fieldLabelstipos_de_goles = array();
$fieldToolTipstipos_de_goles = array();
$pageTitlestipos_de_goles = array();
$placeHolderstipos_de_goles = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelstipos_de_goles["English"] = array();
	$fieldToolTipstipos_de_goles["English"] = array();
	$placeHolderstipos_de_goles["English"] = array();
	$pageTitlestipos_de_goles["English"] = array();
	$fieldLabelstipos_de_goles["English"]["ID"] = "ID";
	$fieldToolTipstipos_de_goles["English"]["ID"] = "";
	$placeHolderstipos_de_goles["English"]["ID"] = "";
	$fieldLabelstipos_de_goles["English"]["Id_Tipo_Gol"] = "Id Tipo Gol";
	$fieldToolTipstipos_de_goles["English"]["Id_Tipo_Gol"] = "";
	$placeHolderstipos_de_goles["English"]["Id_Tipo_Gol"] = "";
	$fieldLabelstipos_de_goles["English"]["Tipo_de_Gol"] = "Tipo de Gol";
	$fieldToolTipstipos_de_goles["English"]["Tipo_de_Gol"] = "";
	$placeHolderstipos_de_goles["English"]["Tipo_de_Gol"] = "";
	if (count($fieldToolTipstipos_de_goles["English"]))
		$tdatatipos_de_goles[".isUseToolTips"] = true;
}


	$tdatatipos_de_goles[".NCSearch"] = true;



$tdatatipos_de_goles[".shortTableName"] = "tipos_de_goles";
$tdatatipos_de_goles[".nSecOptions"] = 0;

$tdatatipos_de_goles[".mainTableOwnerID"] = "";
$tdatatipos_de_goles[".entityType"] = 0;
$tdatatipos_de_goles[".connId"] = "qatar_at_localhost";


$tdatatipos_de_goles[".strOriginalTableName"] = "tipos de goles";

	



$tdatatipos_de_goles[".showAddInPopup"] = false;

$tdatatipos_de_goles[".showEditInPopup"] = false;

$tdatatipos_de_goles[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatatipos_de_goles[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatatipos_de_goles[".listAjax"] = false;
//	temporary
$tdatatipos_de_goles[".listAjax"] = false;

	$tdatatipos_de_goles[".audit"] = false;

	$tdatatipos_de_goles[".locking"] = false;


$pages = $tdatatipos_de_goles[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatatipos_de_goles[".edit"] = true;
	$tdatatipos_de_goles[".afterEditAction"] = 1;
	$tdatatipos_de_goles[".closePopupAfterEdit"] = 1;
	$tdatatipos_de_goles[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatatipos_de_goles[".add"] = true;
$tdatatipos_de_goles[".afterAddAction"] = 1;
$tdatatipos_de_goles[".closePopupAfterAdd"] = 1;
$tdatatipos_de_goles[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatatipos_de_goles[".list"] = true;
}



$tdatatipos_de_goles[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatatipos_de_goles[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatatipos_de_goles[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatatipos_de_goles[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatatipos_de_goles[".printFriendly"] = true;
}



$tdatatipos_de_goles[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatatipos_de_goles[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatatipos_de_goles[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatatipos_de_goles[".isUseAjaxSuggest"] = true;

$tdatatipos_de_goles[".rowHighlite"] = true;





$tdatatipos_de_goles[".ajaxCodeSnippetAdded"] = false;

$tdatatipos_de_goles[".buttonsAdded"] = false;

$tdatatipos_de_goles[".addPageEvents"] = false;

// use timepicker for search panel
$tdatatipos_de_goles[".isUseTimeForSearch"] = false;


$tdatatipos_de_goles[".badgeColor"] = "E8926F";


$tdatatipos_de_goles[".allSearchFields"] = array();
$tdatatipos_de_goles[".filterFields"] = array();
$tdatatipos_de_goles[".requiredSearchFields"] = array();

$tdatatipos_de_goles[".googleLikeFields"] = array();
$tdatatipos_de_goles[".googleLikeFields"][] = "ID";
$tdatatipos_de_goles[".googleLikeFields"][] = "Id Tipo Gol";
$tdatatipos_de_goles[".googleLikeFields"][] = "Tipo de Gol";



$tdatatipos_de_goles[".tableType"] = "list";

$tdatatipos_de_goles[".printerPageOrientation"] = 0;
$tdatatipos_de_goles[".nPrinterPageScale"] = 100;

$tdatatipos_de_goles[".nPrinterSplitRecords"] = 40;

$tdatatipos_de_goles[".geocodingEnabled"] = false;










$tdatatipos_de_goles[".pageSize"] = 20;

$tdatatipos_de_goles[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatatipos_de_goles[".strOrderBy"] = $tstrOrderBy;

$tdatatipos_de_goles[".orderindexes"] = array();


$tdatatipos_de_goles[".sqlHead"] = "SELECT ID,  	`Id Tipo Gol`,  	`Tipo de Gol`";
$tdatatipos_de_goles[".sqlFrom"] = "FROM `Tipos De Goles`";
$tdatatipos_de_goles[".sqlWhereExpr"] = "";
$tdatatipos_de_goles[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatatipos_de_goles[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatatipos_de_goles[".arrGroupsPerPage"] = $arrGPP;

$tdatatipos_de_goles[".highlightSearchResults"] = true;

$tableKeystipos_de_goles = array();
$tableKeystipos_de_goles[] = "ID";
$tdatatipos_de_goles[".Keys"] = $tableKeystipos_de_goles;


$tdatatipos_de_goles[".hideMobileList"] = array();




//	ID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID";
	$fdata["GoodName"] = "ID";
	$fdata["ownerTable"] = "tipos de goles";
	$fdata["Label"] = GetFieldLabel("tipos_de_goles","ID");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "ID";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatatipos_de_goles["ID"] = $fdata;
		$tdatatipos_de_goles[".searchableFields"][] = "ID";
//	Id Tipo Gol
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "Id Tipo Gol";
	$fdata["GoodName"] = "Id_Tipo_Gol";
	$fdata["ownerTable"] = "tipos de goles";
	$fdata["Label"] = GetFieldLabel("tipos_de_goles","Id_Tipo_Gol");
	$fdata["FieldType"] = 3;

	
	
	
			

		$fdata["strField"] = "Id Tipo Gol";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Id Tipo Gol`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatatipos_de_goles["Id Tipo Gol"] = $fdata;
		$tdatatipos_de_goles[".searchableFields"][] = "Id Tipo Gol";
//	Tipo de Gol
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Tipo de Gol";
	$fdata["GoodName"] = "Tipo_de_Gol";
	$fdata["ownerTable"] = "tipos de goles";
	$fdata["Label"] = GetFieldLabel("tipos_de_goles","Tipo_de_Gol");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Tipo de Gol";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Tipo de Gol`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatatipos_de_goles["Tipo de Gol"] = $fdata;
		$tdatatipos_de_goles[".searchableFields"][] = "Tipo de Gol";


$tables_data["tipos de goles"]=&$tdatatipos_de_goles;
$field_labels["tipos_de_goles"] = &$fieldLabelstipos_de_goles;
$fieldToolTips["tipos_de_goles"] = &$fieldToolTipstipos_de_goles;
$placeHolders["tipos_de_goles"] = &$placeHolderstipos_de_goles;
$page_titles["tipos_de_goles"] = &$pageTitlestipos_de_goles;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["tipos de goles"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["tipos de goles"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_tipos_de_goles()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "ID,  	`Id Tipo Gol`,  	`Tipo de Gol`";
$proto0["m_strFrom"] = "FROM `Tipos De Goles`";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "ID",
	"m_strTable" => "tipos de goles",
	"m_srcTableName" => "tipos de goles"
));

$proto6["m_sql"] = "ID";
$proto6["m_srcTableName"] = "tipos de goles";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "Id Tipo Gol",
	"m_strTable" => "tipos de goles",
	"m_srcTableName" => "tipos de goles"
));

$proto8["m_sql"] = "`Id Tipo Gol`";
$proto8["m_srcTableName"] = "tipos de goles";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Tipo de Gol",
	"m_strTable" => "tipos de goles",
	"m_srcTableName" => "tipos de goles"
));

$proto10["m_sql"] = "`Tipo de Gol`";
$proto10["m_srcTableName"] = "tipos de goles";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto12=array();
$proto12["m_link"] = "SQLL_MAIN";
			$proto13=array();
$proto13["m_strName"] = "tipos de goles";
$proto13["m_srcTableName"] = "tipos de goles";
$proto13["m_columns"] = array();
$proto13["m_columns"][] = "ID";
$proto13["m_columns"][] = "Id Tipo Gol";
$proto13["m_columns"][] = "Tipo de Gol";
$obj = new SQLTable($proto13);

$proto12["m_table"] = $obj;
$proto12["m_sql"] = "`Tipos De Goles`";
$proto12["m_alias"] = "";
$proto12["m_srcTableName"] = "tipos de goles";
$proto14=array();
$proto14["m_sql"] = "";
$proto14["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto14["m_column"]=$obj;
$proto14["m_contained"] = array();
$proto14["m_strCase"] = "";
$proto14["m_havingmode"] = false;
$proto14["m_inBrackets"] = false;
$proto14["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto14);

$proto12["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto12);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="tipos de goles";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_tipos_de_goles = createSqlQuery_tipos_de_goles();


	
		;

			

$tdatatipos_de_goles[".sqlquery"] = $queryData_tipos_de_goles;



$tableEvents["tipos de goles"] = new eventsBase;
$tdatatipos_de_goles[".hasEvents"] = false;

?>