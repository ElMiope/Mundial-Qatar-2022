<?php

/**
* getLookupMainTableSettings - tests whether the lookup link exists between the tables
*
*  returns array with ProjectSettings class for main table if the link exists in project settings.
*  returns NULL otherwise
*/
function getLookupMainTableSettings($lookupTable, $mainTableShortName, $mainField, $desiredPage = "")
{
	global $lookupTableLinks;
	if(!isset($lookupTableLinks[$lookupTable]))
		return null;
	if(!isset($lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField]))
		return null;
	$arr = &$lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField];
	$effectivePage = $desiredPage;
	if(!isset($arr[$effectivePage]))
	{
		$effectivePage = PAGE_EDIT;
		if(!isset($arr[$effectivePage]))
		{
			if($desiredPage == "" && 0 < count($arr))
			{
				$effectivePage = $arr[0];
			}
			else
				return null;
		}
	}
	return new ProjectSettings($arr[$effectivePage]["table"], $effectivePage);
}

/** 
* $lookupTableLinks array stores all lookup links between tables in the project
*/
function InitLookupLinks()
{
	global $lookupTableLinks;

	$lookupTableLinks = array();

		if( !isset( $lookupTableLinks["jugadores"] ) ) {
			$lookupTableLinks["jugadores"] = array();
		}
		if( !isset( $lookupTableLinks["jugadores"]["goles.Goleador"] )) {
			$lookupTableLinks["jugadores"]["goles.Goleador"] = array();
		}
		$lookupTableLinks["jugadores"]["goles.Goleador"]["edit"] = array("table" => "goles", "field" => "Goleador", "page" => "edit");
		if( !isset( $lookupTableLinks["tipos de goles"] ) ) {
			$lookupTableLinks["tipos de goles"] = array();
		}
		if( !isset( $lookupTableLinks["tipos de goles"]["goles.Tipo de Gol"] )) {
			$lookupTableLinks["tipos de goles"]["goles.Tipo de Gol"] = array();
		}
		$lookupTableLinks["tipos de goles"]["goles.Tipo de Gol"]["edit"] = array("table" => "goles", "field" => "Tipo de Gol", "page" => "edit");
		if( !isset( $lookupTableLinks["estadios"] ) ) {
			$lookupTableLinks["estadios"] = array();
		}
		if( !isset( $lookupTableLinks["estadios"]["partidos.Nombre del Estadio"] )) {
			$lookupTableLinks["estadios"]["partidos.Nombre del Estadio"] = array();
		}
		$lookupTableLinks["estadios"]["partidos.Nombre del Estadio"]["edit"] = array("table" => "partidos", "field" => "Nombre del Estadio", "page" => "edit");
		if( !isset( $lookupTableLinks["selecciones"] ) ) {
			$lookupTableLinks["selecciones"] = array();
		}
		if( !isset( $lookupTableLinks["selecciones"]["partidos.Local"] )) {
			$lookupTableLinks["selecciones"]["partidos.Local"] = array();
		}
		$lookupTableLinks["selecciones"]["partidos.Local"]["edit"] = array("table" => "partidos", "field" => "Local", "page" => "edit");
		if( !isset( $lookupTableLinks["selecciones"] ) ) {
			$lookupTableLinks["selecciones"] = array();
		}
		if( !isset( $lookupTableLinks["selecciones"]["partidos.Visitante"] )) {
			$lookupTableLinks["selecciones"]["partidos.Visitante"] = array();
		}
		$lookupTableLinks["selecciones"]["partidos.Visitante"]["edit"] = array("table" => "partidos", "field" => "Visitante", "page" => "edit");
		if( !isset( $lookupTableLinks["posiciones"] ) ) {
			$lookupTableLinks["posiciones"] = array();
		}
		if( !isset( $lookupTableLinks["posiciones"]["jugadores.Posicion"] )) {
			$lookupTableLinks["posiciones"]["jugadores.Posicion"] = array();
		}
		$lookupTableLinks["posiciones"]["jugadores.Posicion"]["edit"] = array("table" => "jugadores", "field" => "Posicion", "page" => "edit");
		if( !isset( $lookupTableLinks["selecciones"] ) ) {
			$lookupTableLinks["selecciones"] = array();
		}
		if( !isset( $lookupTableLinks["selecciones"]["jugadores.Seleccion"] )) {
			$lookupTableLinks["selecciones"]["jugadores.Seleccion"] = array();
		}
		$lookupTableLinks["selecciones"]["jugadores.Seleccion"]["edit"] = array("table" => "jugadores", "field" => "Seleccion", "page" => "edit");
		if( !isset( $lookupTableLinks["colores"] ) ) {
			$lookupTableLinks["colores"] = array();
		}
		if( !isset( $lookupTableLinks["colores"]["selecciones.Color Camiseta"] )) {
			$lookupTableLinks["colores"]["selecciones.Color Camiseta"] = array();
		}
		$lookupTableLinks["colores"]["selecciones.Color Camiseta"]["edit"] = array("table" => "selecciones", "field" => "Color Camiseta", "page" => "edit");
		if( !isset( $lookupTableLinks["colores"] ) ) {
			$lookupTableLinks["colores"] = array();
		}
		if( !isset( $lookupTableLinks["colores"]["selecciones.Color Pantalones"] )) {
			$lookupTableLinks["colores"]["selecciones.Color Pantalones"] = array();
		}
		$lookupTableLinks["colores"]["selecciones.Color Pantalones"]["edit"] = array("table" => "selecciones", "field" => "Color Pantalones", "page" => "edit");
		if( !isset( $lookupTableLinks["colores"] ) ) {
			$lookupTableLinks["colores"] = array();
		}
		if( !isset( $lookupTableLinks["colores"]["selecciones.Color Medias"] )) {
			$lookupTableLinks["colores"]["selecciones.Color Medias"] = array();
		}
		$lookupTableLinks["colores"]["selecciones.Color Medias"]["edit"] = array("table" => "selecciones", "field" => "Color Medias", "page" => "edit");
		if( !isset( $lookupTableLinks["dts"] ) ) {
			$lookupTableLinks["dts"] = array();
		}
		if( !isset( $lookupTableLinks["dts"]["selecciones.Id DT"] )) {
			$lookupTableLinks["dts"]["selecciones.Id DT"] = array();
		}
		$lookupTableLinks["dts"]["selecciones.Id DT"]["edit"] = array("table" => "selecciones", "field" => "Id DT", "page" => "edit");
}

?>