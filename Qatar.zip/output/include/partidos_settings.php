<?php
$tdatapartidos = array();
$tdatapartidos[".searchableFields"] = array();
$tdatapartidos[".ShortName"] = "partidos";
$tdatapartidos[".OwnerID"] = "";
$tdatapartidos[".OriginalTable"] = "partidos";


$tdatapartidos[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatapartidos[".originalPagesByType"] = $tdatapartidos[".pagesByType"];
$tdatapartidos[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatapartidos[".originalPages"] = $tdatapartidos[".pages"];
$tdatapartidos[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatapartidos[".originalDefaultPages"] = $tdatapartidos[".defaultPages"];

//	field labels
$fieldLabelspartidos = array();
$fieldToolTipspartidos = array();
$pageTitlespartidos = array();
$placeHolderspartidos = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelspartidos["English"] = array();
	$fieldToolTipspartidos["English"] = array();
	$placeHolderspartidos["English"] = array();
	$pageTitlespartidos["English"] = array();
	$fieldLabelspartidos["English"]["ID"] = "ID";
	$fieldToolTipspartidos["English"]["ID"] = "";
	$placeHolderspartidos["English"]["ID"] = "";
	$fieldLabelspartidos["English"]["Fecha"] = "Fecha";
	$fieldToolTipspartidos["English"]["Fecha"] = "";
	$placeHolderspartidos["English"]["Fecha"] = "";
	$fieldLabelspartidos["English"]["Nombre_del_Estadio"] = "Nombre del Estadio";
	$fieldToolTipspartidos["English"]["Nombre_del_Estadio"] = "";
	$placeHolderspartidos["English"]["Nombre_del_Estadio"] = "";
	$fieldLabelspartidos["English"]["Hora"] = "Hora";
	$fieldToolTipspartidos["English"]["Hora"] = "";
	$placeHolderspartidos["English"]["Hora"] = "";
	$fieldLabelspartidos["English"]["Local"] = "Local";
	$fieldToolTipspartidos["English"]["Local"] = "";
	$placeHolderspartidos["English"]["Local"] = "";
	$fieldLabelspartidos["English"]["Visitante"] = "Visitante";
	$fieldToolTipspartidos["English"]["Visitante"] = "";
	$placeHolderspartidos["English"]["Visitante"] = "";
	$fieldLabelspartidos["English"]["Goles_Local"] = "Goles Local";
	$fieldToolTipspartidos["English"]["Goles_Local"] = "";
	$placeHolderspartidos["English"]["Goles_Local"] = "";
	$fieldLabelspartidos["English"]["Goles_Visitantes"] = "Goles Visitantes";
	$fieldToolTipspartidos["English"]["Goles_Visitantes"] = "";
	$placeHolderspartidos["English"]["Goles_Visitantes"] = "";
	if (count($fieldToolTipspartidos["English"]))
		$tdatapartidos[".isUseToolTips"] = true;
}


	$tdatapartidos[".NCSearch"] = true;



$tdatapartidos[".shortTableName"] = "partidos";
$tdatapartidos[".nSecOptions"] = 0;

$tdatapartidos[".mainTableOwnerID"] = "";
$tdatapartidos[".entityType"] = 0;
$tdatapartidos[".connId"] = "qatar_at_localhost";


$tdatapartidos[".strOriginalTableName"] = "partidos";

	



$tdatapartidos[".showAddInPopup"] = false;

$tdatapartidos[".showEditInPopup"] = false;

$tdatapartidos[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatapartidos[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatapartidos[".listAjax"] = false;
//	temporary
$tdatapartidos[".listAjax"] = false;

	$tdatapartidos[".audit"] = false;

	$tdatapartidos[".locking"] = false;


$pages = $tdatapartidos[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatapartidos[".edit"] = true;
	$tdatapartidos[".afterEditAction"] = 1;
	$tdatapartidos[".closePopupAfterEdit"] = 1;
	$tdatapartidos[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatapartidos[".add"] = true;
$tdatapartidos[".afterAddAction"] = 1;
$tdatapartidos[".closePopupAfterAdd"] = 1;
$tdatapartidos[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatapartidos[".list"] = true;
}



$tdatapartidos[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatapartidos[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatapartidos[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatapartidos[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatapartidos[".printFriendly"] = true;
}



$tdatapartidos[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatapartidos[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatapartidos[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatapartidos[".isUseAjaxSuggest"] = true;

$tdatapartidos[".rowHighlite"] = true;





$tdatapartidos[".ajaxCodeSnippetAdded"] = false;

$tdatapartidos[".buttonsAdded"] = false;

$tdatapartidos[".addPageEvents"] = false;

// use timepicker for search panel
$tdatapartidos[".isUseTimeForSearch"] = false;


$tdatapartidos[".badgeColor"] = "DAA520";


$tdatapartidos[".allSearchFields"] = array();
$tdatapartidos[".filterFields"] = array();
$tdatapartidos[".requiredSearchFields"] = array();

$tdatapartidos[".googleLikeFields"] = array();
$tdatapartidos[".googleLikeFields"][] = "ID";
$tdatapartidos[".googleLikeFields"][] = "Fecha";
$tdatapartidos[".googleLikeFields"][] = "Hora";
$tdatapartidos[".googleLikeFields"][] = "Nombre del Estadio";
$tdatapartidos[".googleLikeFields"][] = "Local";
$tdatapartidos[".googleLikeFields"][] = "Visitante";
$tdatapartidos[".googleLikeFields"][] = "Goles Local";
$tdatapartidos[".googleLikeFields"][] = "Goles Visitantes";



$tdatapartidos[".tableType"] = "list";

$tdatapartidos[".printerPageOrientation"] = 0;
$tdatapartidos[".nPrinterPageScale"] = 100;

$tdatapartidos[".nPrinterSplitRecords"] = 40;

$tdatapartidos[".geocodingEnabled"] = false;










$tdatapartidos[".pageSize"] = 20;

$tdatapartidos[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatapartidos[".strOrderBy"] = $tstrOrderBy;

$tdatapartidos[".orderindexes"] = array();


$tdatapartidos[".sqlHead"] = "SELECT ID,  	Fecha,  	Hora,  	`Nombre del Estadio`,  	`Local`,  	Visitante,  	`Goles Local`,  	`Goles Visitantes`";
$tdatapartidos[".sqlFrom"] = "FROM partidos";
$tdatapartidos[".sqlWhereExpr"] = "";
$tdatapartidos[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatapartidos[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatapartidos[".arrGroupsPerPage"] = $arrGPP;

$tdatapartidos[".highlightSearchResults"] = true;

$tableKeyspartidos = array();
$tableKeyspartidos[] = "ID";
$tdatapartidos[".Keys"] = $tableKeyspartidos;


$tdatapartidos[".hideMobileList"] = array();




//	ID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID";
	$fdata["GoodName"] = "ID";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","ID");
	$fdata["FieldType"] = 3;

	
		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "ID";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["ID"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "ID";
//	Fecha
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "Fecha";
	$fdata["GoodName"] = "Fecha";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","Fecha");
	$fdata["FieldType"] = 7;

	
	
	
			

		$fdata["strField"] = "Fecha";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Fecha";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["Fecha"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "Fecha";
//	Hora
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Hora";
	$fdata["GoodName"] = "Hora";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","Hora");
	$fdata["FieldType"] = 134;

	
	
	
			

		$fdata["strField"] = "Hora";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Hora";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Time");

	
	
	
	
	
	
	
	
	
	
	
		
		$vdata["timeFormatData"] = array(
		"showSeconds" => false,
		"showDaysInTotals" => false,
		"timeFormat" => 0
	);
	$vdata["timeFormatData"]["showSeconds"] = true;
	$vdata["timeFormatData"]["showDaysInTotals"] = true;

		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Time");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
				$hours = 24;
	$edata["FormatTimeAttrs"] = array("useTimePicker" => 0,
									  "hours" => $hours,
									  "minutes" => 1,
									  "showSeconds" => 0);

	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["Hora"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "Hora";
//	Nombre del Estadio
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Nombre del Estadio";
	$fdata["GoodName"] = "Nombre_del_Estadio";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","Nombre_del_Estadio");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Nombre del Estadio";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Nombre del Estadio`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "estadios";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Nombre";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Nombre";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["Nombre del Estadio"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "Nombre del Estadio";
//	Local
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Local";
	$fdata["GoodName"] = "Local";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","Local");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Local";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Local`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "selecciones";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Nombre";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Nombre";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["Local"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "Local";
//	Visitante
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Visitante";
	$fdata["GoodName"] = "Visitante";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","Visitante");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Visitante";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Visitante";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "selecciones";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Nombre";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Nombre";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["Visitante"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "Visitante";
//	Goles Local
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "Goles Local";
	$fdata["GoodName"] = "Goles_Local";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","Goles_Local");
	$fdata["FieldType"] = 3;

	
	
	
			

		$fdata["strField"] = "Goles Local";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Goles Local`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["Goles Local"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "Goles Local";
//	Goles Visitantes
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "Goles Visitantes";
	$fdata["GoodName"] = "Goles_Visitantes";
	$fdata["ownerTable"] = "partidos";
	$fdata["Label"] = GetFieldLabel("partidos","Goles_Visitantes");
	$fdata["FieldType"] = 3;

	
	
	
			

		$fdata["strField"] = "Goles Visitantes";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Goles Visitantes`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatapartidos["Goles Visitantes"] = $fdata;
		$tdatapartidos[".searchableFields"][] = "Goles Visitantes";


$tables_data["partidos"]=&$tdatapartidos;
$field_labels["partidos"] = &$fieldLabelspartidos;
$fieldToolTips["partidos"] = &$fieldToolTipspartidos;
$placeHolders["partidos"] = &$placeHolderspartidos;
$page_titles["partidos"] = &$pageTitlespartidos;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["partidos"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["partidos"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_partidos()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "ID,  	Fecha,  	Hora,  	`Nombre del Estadio`,  	`Local`,  	Visitante,  	`Goles Local`,  	`Goles Visitantes`";
$proto0["m_strFrom"] = "FROM partidos";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "ID",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto6["m_sql"] = "ID";
$proto6["m_srcTableName"] = "partidos";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "Fecha",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto8["m_sql"] = "Fecha";
$proto8["m_srcTableName"] = "partidos";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Hora",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto10["m_sql"] = "Hora";
$proto10["m_srcTableName"] = "partidos";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Nombre del Estadio",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto12["m_sql"] = "`Nombre del Estadio`";
$proto12["m_srcTableName"] = "partidos";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Local",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto14["m_sql"] = "`Local`";
$proto14["m_srcTableName"] = "partidos";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "Visitante",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto16["m_sql"] = "Visitante";
$proto16["m_srcTableName"] = "partidos";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "Goles Local",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto18["m_sql"] = "`Goles Local`";
$proto18["m_srcTableName"] = "partidos";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "Goles Visitantes",
	"m_strTable" => "partidos",
	"m_srcTableName" => "partidos"
));

$proto20["m_sql"] = "`Goles Visitantes`";
$proto20["m_srcTableName"] = "partidos";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto22=array();
$proto22["m_link"] = "SQLL_MAIN";
			$proto23=array();
$proto23["m_strName"] = "partidos";
$proto23["m_srcTableName"] = "partidos";
$proto23["m_columns"] = array();
$proto23["m_columns"][] = "ID";
$proto23["m_columns"][] = "Fecha";
$proto23["m_columns"][] = "Hora";
$proto23["m_columns"][] = "Nombre del Estadio";
$proto23["m_columns"][] = "Local";
$proto23["m_columns"][] = "Visitante";
$proto23["m_columns"][] = "Goles Local";
$proto23["m_columns"][] = "Goles Visitantes";
$obj = new SQLTable($proto23);

$proto22["m_table"] = $obj;
$proto22["m_sql"] = "partidos";
$proto22["m_alias"] = "";
$proto22["m_srcTableName"] = "partidos";
$proto24=array();
$proto24["m_sql"] = "";
$proto24["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto24["m_column"]=$obj;
$proto24["m_contained"] = array();
$proto24["m_strCase"] = "";
$proto24["m_havingmode"] = false;
$proto24["m_inBrackets"] = false;
$proto24["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto24);

$proto22["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto22);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="partidos";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_partidos = createSqlQuery_partidos();


	
		;

								

$tdatapartidos[".sqlquery"] = $queryData_partidos;



$tableEvents["partidos"] = new eventsBase;
$tdatapartidos[".hasEvents"] = false;

?>