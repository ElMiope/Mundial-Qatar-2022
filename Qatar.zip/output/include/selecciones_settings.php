<?php
$tdataselecciones = array();
$tdataselecciones[".searchableFields"] = array();
$tdataselecciones[".ShortName"] = "selecciones";
$tdataselecciones[".OwnerID"] = "";
$tdataselecciones[".OriginalTable"] = "selecciones";


$tdataselecciones[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdataselecciones[".originalPagesByType"] = $tdataselecciones[".pagesByType"];
$tdataselecciones[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdataselecciones[".originalPages"] = $tdataselecciones[".pages"];
$tdataselecciones[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdataselecciones[".originalDefaultPages"] = $tdataselecciones[".defaultPages"];

//	field labels
$fieldLabelsselecciones = array();
$fieldToolTipsselecciones = array();
$pageTitlesselecciones = array();
$placeHoldersselecciones = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsselecciones["English"] = array();
	$fieldToolTipsselecciones["English"] = array();
	$placeHoldersselecciones["English"] = array();
	$pageTitlesselecciones["English"] = array();
	$fieldLabelsselecciones["English"]["Id"] = "Id";
	$fieldToolTipsselecciones["English"]["Id"] = "";
	$placeHoldersselecciones["English"]["Id"] = "";
	$fieldLabelsselecciones["English"]["Nombre"] = "Nombre";
	$fieldToolTipsselecciones["English"]["Nombre"] = "";
	$placeHoldersselecciones["English"]["Nombre"] = "";
	$fieldLabelsselecciones["English"]["Color_Camiseta"] = "Color Camiseta";
	$fieldToolTipsselecciones["English"]["Color_Camiseta"] = "";
	$placeHoldersselecciones["English"]["Color_Camiseta"] = "";
	$fieldLabelsselecciones["English"]["Color_Pantalones"] = "Color Pantalones";
	$fieldToolTipsselecciones["English"]["Color_Pantalones"] = "";
	$placeHoldersselecciones["English"]["Color_Pantalones"] = "";
	$fieldLabelsselecciones["English"]["Color_Medias"] = "Color Medias";
	$fieldToolTipsselecciones["English"]["Color_Medias"] = "";
	$placeHoldersselecciones["English"]["Color_Medias"] = "";
	$fieldLabelsselecciones["English"]["Id_DT"] = "Id DT";
	$fieldToolTipsselecciones["English"]["Id_DT"] = "";
	$placeHoldersselecciones["English"]["Id_DT"] = "";
	if (count($fieldToolTipsselecciones["English"]))
		$tdataselecciones[".isUseToolTips"] = true;
}


	$tdataselecciones[".NCSearch"] = true;



$tdataselecciones[".shortTableName"] = "selecciones";
$tdataselecciones[".nSecOptions"] = 0;

$tdataselecciones[".mainTableOwnerID"] = "";
$tdataselecciones[".entityType"] = 0;
$tdataselecciones[".connId"] = "qatar_at_localhost";


$tdataselecciones[".strOriginalTableName"] = "selecciones";

	



$tdataselecciones[".showAddInPopup"] = false;

$tdataselecciones[".showEditInPopup"] = false;

$tdataselecciones[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataselecciones[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataselecciones[".listAjax"] = false;
//	temporary
$tdataselecciones[".listAjax"] = false;

	$tdataselecciones[".audit"] = false;

	$tdataselecciones[".locking"] = false;


$pages = $tdataselecciones[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataselecciones[".edit"] = true;
	$tdataselecciones[".afterEditAction"] = 1;
	$tdataselecciones[".closePopupAfterEdit"] = 1;
	$tdataselecciones[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataselecciones[".add"] = true;
$tdataselecciones[".afterAddAction"] = 1;
$tdataselecciones[".closePopupAfterAdd"] = 1;
$tdataselecciones[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataselecciones[".list"] = true;
}



$tdataselecciones[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataselecciones[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataselecciones[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataselecciones[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataselecciones[".printFriendly"] = true;
}



$tdataselecciones[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataselecciones[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataselecciones[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataselecciones[".isUseAjaxSuggest"] = true;

$tdataselecciones[".rowHighlite"] = true;





$tdataselecciones[".ajaxCodeSnippetAdded"] = false;

$tdataselecciones[".buttonsAdded"] = false;

$tdataselecciones[".addPageEvents"] = false;

// use timepicker for search panel
$tdataselecciones[".isUseTimeForSearch"] = false;


$tdataselecciones[".badgeColor"] = "DAA520";


$tdataselecciones[".allSearchFields"] = array();
$tdataselecciones[".filterFields"] = array();
$tdataselecciones[".requiredSearchFields"] = array();

$tdataselecciones[".googleLikeFields"] = array();
$tdataselecciones[".googleLikeFields"][] = "Id";
$tdataselecciones[".googleLikeFields"][] = "Nombre";
$tdataselecciones[".googleLikeFields"][] = "Color Camiseta";
$tdataselecciones[".googleLikeFields"][] = "Color Pantalones";
$tdataselecciones[".googleLikeFields"][] = "Color Medias";
$tdataselecciones[".googleLikeFields"][] = "Id DT";



$tdataselecciones[".tableType"] = "list";

$tdataselecciones[".printerPageOrientation"] = 0;
$tdataselecciones[".nPrinterPageScale"] = 100;

$tdataselecciones[".nPrinterSplitRecords"] = 40;

$tdataselecciones[".geocodingEnabled"] = false;










$tdataselecciones[".pageSize"] = 20;

$tdataselecciones[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataselecciones[".strOrderBy"] = $tstrOrderBy;

$tdataselecciones[".orderindexes"] = array();


$tdataselecciones[".sqlHead"] = "SELECT Id,  	Nombre,  	`Color Camiseta`,  	`Color Pantalones`,  	`Color Medias`,  	`Id DT`";
$tdataselecciones[".sqlFrom"] = "FROM selecciones";
$tdataselecciones[".sqlWhereExpr"] = "";
$tdataselecciones[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataselecciones[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataselecciones[".arrGroupsPerPage"] = $arrGPP;

$tdataselecciones[".highlightSearchResults"] = true;

$tableKeysselecciones = array();
$tableKeysselecciones[] = "Id";
$tdataselecciones[".Keys"] = $tableKeysselecciones;


$tdataselecciones[".hideMobileList"] = array();




//	Id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "Id";
	$fdata["GoodName"] = "Id";
	$fdata["ownerTable"] = "selecciones";
	$fdata["Label"] = GetFieldLabel("selecciones","Id");
	$fdata["FieldType"] = 3;

	
	
	
			

		$fdata["strField"] = "Id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataselecciones["Id"] = $fdata;
		$tdataselecciones[".searchableFields"][] = "Id";
//	Nombre
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "Nombre";
	$fdata["GoodName"] = "Nombre";
	$fdata["ownerTable"] = "selecciones";
	$fdata["Label"] = GetFieldLabel("selecciones","Nombre");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Nombre";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Nombre";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataselecciones["Nombre"] = $fdata;
		$tdataselecciones[".searchableFields"][] = "Nombre";
//	Color Camiseta
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Color Camiseta";
	$fdata["GoodName"] = "Color_Camiseta";
	$fdata["ownerTable"] = "selecciones";
	$fdata["Label"] = GetFieldLabel("selecciones","Color_Camiseta");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Color Camiseta";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Color Camiseta`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "colores";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Id Color";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Color";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataselecciones["Color Camiseta"] = $fdata;
		$tdataselecciones[".searchableFields"][] = "Color Camiseta";
//	Color Pantalones
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Color Pantalones";
	$fdata["GoodName"] = "Color_Pantalones";
	$fdata["ownerTable"] = "selecciones";
	$fdata["Label"] = GetFieldLabel("selecciones","Color_Pantalones");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Color Pantalones";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Color Pantalones`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "colores";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Id Color";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Color";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataselecciones["Color Pantalones"] = $fdata;
		$tdataselecciones[".searchableFields"][] = "Color Pantalones";
//	Color Medias
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Color Medias";
	$fdata["GoodName"] = "Color_Medias";
	$fdata["ownerTable"] = "selecciones";
	$fdata["Label"] = GetFieldLabel("selecciones","Color_Medias");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Color Medias";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Color Medias`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "colores";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Id Color";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Color";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataselecciones["Color Medias"] = $fdata;
		$tdataselecciones[".searchableFields"][] = "Color Medias";
//	Id DT
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Id DT";
	$fdata["GoodName"] = "Id_DT";
	$fdata["ownerTable"] = "selecciones";
	$fdata["Label"] = GetFieldLabel("selecciones","Id_DT");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Id DT";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Id DT`";

	
	
			
//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "dts";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "DT";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "DT";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataselecciones["Id DT"] = $fdata;
		$tdataselecciones[".searchableFields"][] = "Id DT";


$tables_data["selecciones"]=&$tdataselecciones;
$field_labels["selecciones"] = &$fieldLabelsselecciones;
$fieldToolTips["selecciones"] = &$fieldToolTipsselecciones;
$placeHolders["selecciones"] = &$placeHoldersselecciones;
$page_titles["selecciones"] = &$pageTitlesselecciones;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["selecciones"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["selecciones"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_selecciones()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "Id,  	Nombre,  	`Color Camiseta`,  	`Color Pantalones`,  	`Color Medias`,  	`Id DT`";
$proto0["m_strFrom"] = "FROM selecciones";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "Id",
	"m_strTable" => "selecciones",
	"m_srcTableName" => "selecciones"
));

$proto6["m_sql"] = "Id";
$proto6["m_srcTableName"] = "selecciones";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "Nombre",
	"m_strTable" => "selecciones",
	"m_srcTableName" => "selecciones"
));

$proto8["m_sql"] = "Nombre";
$proto8["m_srcTableName"] = "selecciones";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Color Camiseta",
	"m_strTable" => "selecciones",
	"m_srcTableName" => "selecciones"
));

$proto10["m_sql"] = "`Color Camiseta`";
$proto10["m_srcTableName"] = "selecciones";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Color Pantalones",
	"m_strTable" => "selecciones",
	"m_srcTableName" => "selecciones"
));

$proto12["m_sql"] = "`Color Pantalones`";
$proto12["m_srcTableName"] = "selecciones";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Color Medias",
	"m_strTable" => "selecciones",
	"m_srcTableName" => "selecciones"
));

$proto14["m_sql"] = "`Color Medias`";
$proto14["m_srcTableName"] = "selecciones";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "Id DT",
	"m_strTable" => "selecciones",
	"m_srcTableName" => "selecciones"
));

$proto16["m_sql"] = "`Id DT`";
$proto16["m_srcTableName"] = "selecciones";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto18=array();
$proto18["m_link"] = "SQLL_MAIN";
			$proto19=array();
$proto19["m_strName"] = "selecciones";
$proto19["m_srcTableName"] = "selecciones";
$proto19["m_columns"] = array();
$proto19["m_columns"][] = "Id";
$proto19["m_columns"][] = "Nombre";
$proto19["m_columns"][] = "Color Camiseta";
$proto19["m_columns"][] = "Color Pantalones";
$proto19["m_columns"][] = "Color Medias";
$proto19["m_columns"][] = "Id DT";
$obj = new SQLTable($proto19);

$proto18["m_table"] = $obj;
$proto18["m_sql"] = "selecciones";
$proto18["m_alias"] = "";
$proto18["m_srcTableName"] = "selecciones";
$proto20=array();
$proto20["m_sql"] = "";
$proto20["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto20["m_column"]=$obj;
$proto20["m_contained"] = array();
$proto20["m_strCase"] = "";
$proto20["m_havingmode"] = false;
$proto20["m_inBrackets"] = false;
$proto20["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto20);

$proto18["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto18);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="selecciones";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_selecciones = createSqlQuery_selecciones();


	
		;

						

$tdataselecciones[".sqlquery"] = $queryData_selecciones;



$tableEvents["selecciones"] = new eventsBase;
$tdataselecciones[".hasEvents"] = false;

?>