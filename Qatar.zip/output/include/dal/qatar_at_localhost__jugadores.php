<?php
$dalTablejugadores = array();
$dalTablejugadores["Id"] = array("type"=>3,"varname"=>"Id", "name" => "Id");
$dalTablejugadores["Nombre y apellido"] = array("type"=>200,"varname"=>"Nombre_y_apellido", "name" => "Nombre y apellido");
$dalTablejugadores["Posicion"] = array("type"=>200,"varname"=>"Posicion", "name" => "Posicion");
$dalTablejugadores["Numero Camiseta"] = array("type"=>3,"varname"=>"Numero_Camiseta", "name" => "Numero Camiseta");
$dalTablejugadores["Seleccion"] = array("type"=>200,"varname"=>"Seleccion", "name" => "Seleccion");
	$dalTablejugadores["Id"]["key"]=true;

$dal_info["qatar_at_localhost__jugadores"] = &$dalTablejugadores;
?>