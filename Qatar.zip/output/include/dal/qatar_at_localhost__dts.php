<?php
$dalTabledts = array();
$dalTabledts["Id DT"] = array("type"=>3,"varname"=>"Id_DT", "name" => "Id DT");
$dalTabledts["DT"] = array("type"=>200,"varname"=>"DT", "name" => "DT");
$dalTabledts["Cantidad de años en el cargo"] = array("type"=>3,"varname"=>"Cantidad_de_a_os_en_el_cargo", "name" => "Cantidad de años en el cargo");
	$dalTabledts["Id DT"]["key"]=true;

$dal_info["qatar_at_localhost__dts"] = &$dalTabledts;
?>