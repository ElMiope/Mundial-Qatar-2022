<?php
$dalTableposiciones = array();
$dalTableposiciones["IdPosicion"] = array("type"=>3,"varname"=>"IdPosicion", "name" => "IdPosicion");
$dalTableposiciones["Posiciones"] = array("type"=>200,"varname"=>"Posiciones", "name" => "Posiciones");
	$dalTableposiciones["IdPosicion"]["key"]=true;

$dal_info["qatar_at_localhost__posiciones"] = &$dalTableposiciones;
?>