<?php
$dalTablepartidos = array();
$dalTablepartidos["ID"] = array("type"=>3,"varname"=>"ID", "name" => "ID");
$dalTablepartidos["Fecha"] = array("type"=>7,"varname"=>"Fecha", "name" => "Fecha");
$dalTablepartidos["Hora"] = array("type"=>134,"varname"=>"Hora", "name" => "Hora");
$dalTablepartidos["Nombre del Estadio"] = array("type"=>200,"varname"=>"Nombre_del_Estadio", "name" => "Nombre del Estadio");
$dalTablepartidos["Local"] = array("type"=>200,"varname"=>"Local", "name" => "Local");
$dalTablepartidos["Visitante"] = array("type"=>200,"varname"=>"Visitante", "name" => "Visitante");
$dalTablepartidos["Goles Local"] = array("type"=>3,"varname"=>"Goles_Local", "name" => "Goles Local");
$dalTablepartidos["Goles Visitantes"] = array("type"=>3,"varname"=>"Goles_Visitantes", "name" => "Goles Visitantes");
	$dalTablepartidos["ID"]["key"]=true;

$dal_info["qatar_at_localhost__partidos"] = &$dalTablepartidos;
?>