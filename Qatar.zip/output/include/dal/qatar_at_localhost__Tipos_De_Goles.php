<?php
$dalTabletipos_de_goles = array();
$dalTabletipos_de_goles["ID"] = array("type"=>3,"varname"=>"ID", "name" => "ID");
$dalTabletipos_de_goles["Id Tipo Gol"] = array("type"=>3,"varname"=>"Id_Tipo_Gol", "name" => "Id Tipo Gol");
$dalTabletipos_de_goles["Tipo de Gol"] = array("type"=>200,"varname"=>"Tipo_de_Gol", "name" => "Tipo de Gol");
	$dalTabletipos_de_goles["ID"]["key"]=true;

$dal_info["qatar_at_localhost__tipos_de_goles"] = &$dalTabletipos_de_goles;
?>