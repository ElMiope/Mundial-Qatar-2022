<?php
$dalTablegoles = array();
$dalTablegoles["ID"] = array("type"=>3,"varname"=>"ID", "name" => "ID");
$dalTablegoles["Goleador"] = array("type"=>200,"varname"=>"Goleador", "name" => "Goleador");
$dalTablegoles["Minuto"] = array("type"=>134,"varname"=>"Minuto", "name" => "Minuto");
$dalTablegoles["Tipo de Gol"] = array("type"=>200,"varname"=>"Tipo_de_Gol", "name" => "Tipo de Gol");
	$dalTablegoles["ID"]["key"]=true;

$dal_info["qatar_at_localhost__goles"] = &$dalTablegoles;
?>