<?php
$dalTablecolores = array();
$dalTablecolores["Id Color"] = array("type"=>3,"varname"=>"Id_Color", "name" => "Id Color");
$dalTablecolores["Color"] = array("type"=>200,"varname"=>"Color", "name" => "Color");
	$dalTablecolores["Id Color"]["key"]=true;

$dal_info["qatar_at_localhost__colores"] = &$dalTablecolores;
?>