<?php
$dalTableselecciones = array();
$dalTableselecciones["Id"] = array("type"=>3,"varname"=>"Id", "name" => "Id");
$dalTableselecciones["Nombre"] = array("type"=>200,"varname"=>"Nombre", "name" => "Nombre");
$dalTableselecciones["Color Camiseta"] = array("type"=>200,"varname"=>"Color_Camiseta", "name" => "Color Camiseta");
$dalTableselecciones["Color Pantalones"] = array("type"=>200,"varname"=>"Color_Pantalones", "name" => "Color Pantalones");
$dalTableselecciones["Color Medias"] = array("type"=>200,"varname"=>"Color_Medias", "name" => "Color Medias");
$dalTableselecciones["Id DT"] = array("type"=>200,"varname"=>"Id_DT", "name" => "Id DT");
	$dalTableselecciones["Id"]["key"]=true;

$dal_info["qatar_at_localhost__selecciones"] = &$dalTableselecciones;
?>