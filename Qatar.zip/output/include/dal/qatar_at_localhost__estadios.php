<?php
$dalTableestadios = array();
$dalTableestadios["ID0"] = array("type"=>3,"varname"=>"ID0", "name" => "ID0");
$dalTableestadios["Nombre"] = array("type"=>200,"varname"=>"Nombre", "name" => "Nombre");
$dalTableestadios["Capacidad"] = array("type"=>3,"varname"=>"Capacidad", "name" => "Capacidad");
$dalTableestadios["Ciudad"] = array("type"=>200,"varname"=>"Ciudad", "name" => "Ciudad");
	$dalTableestadios["ID0"]["key"]=true;

$dal_info["qatar_at_localhost__estadios"] = &$dalTableestadios;
?>