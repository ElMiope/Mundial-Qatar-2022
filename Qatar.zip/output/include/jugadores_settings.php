<?php
$tdatajugadores = array();
$tdatajugadores[".searchableFields"] = array();
$tdatajugadores[".ShortName"] = "jugadores";
$tdatajugadores[".OwnerID"] = "";
$tdatajugadores[".OriginalTable"] = "jugadores";


$tdatajugadores[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatajugadores[".originalPagesByType"] = $tdatajugadores[".pagesByType"];
$tdatajugadores[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatajugadores[".originalPages"] = $tdatajugadores[".pages"];
$tdatajugadores[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatajugadores[".originalDefaultPages"] = $tdatajugadores[".defaultPages"];

//	field labels
$fieldLabelsjugadores = array();
$fieldToolTipsjugadores = array();
$pageTitlesjugadores = array();
$placeHoldersjugadores = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsjugadores["English"] = array();
	$fieldToolTipsjugadores["English"] = array();
	$placeHoldersjugadores["English"] = array();
	$pageTitlesjugadores["English"] = array();
	$fieldLabelsjugadores["English"]["Id"] = "Id";
	$fieldToolTipsjugadores["English"]["Id"] = "";
	$placeHoldersjugadores["English"]["Id"] = "";
	$fieldLabelsjugadores["English"]["Nombre_y_apellido"] = "Nombre y apellido";
	$fieldToolTipsjugadores["English"]["Nombre_y_apellido"] = "";
	$placeHoldersjugadores["English"]["Nombre_y_apellido"] = "";
	$fieldLabelsjugadores["English"]["Posicion"] = "Posicion";
	$fieldToolTipsjugadores["English"]["Posicion"] = "";
	$placeHoldersjugadores["English"]["Posicion"] = "";
	$fieldLabelsjugadores["English"]["Numero_Camiseta"] = "Numero Camiseta";
	$fieldToolTipsjugadores["English"]["Numero_Camiseta"] = "";
	$placeHoldersjugadores["English"]["Numero_Camiseta"] = "";
	$fieldLabelsjugadores["English"]["Seleccion"] = "Seleccion";
	$fieldToolTipsjugadores["English"]["Seleccion"] = "";
	$placeHoldersjugadores["English"]["Seleccion"] = "";
	if (count($fieldToolTipsjugadores["English"]))
		$tdatajugadores[".isUseToolTips"] = true;
}


	$tdatajugadores[".NCSearch"] = true;



$tdatajugadores[".shortTableName"] = "jugadores";
$tdatajugadores[".nSecOptions"] = 0;

$tdatajugadores[".mainTableOwnerID"] = "";
$tdatajugadores[".entityType"] = 0;
$tdatajugadores[".connId"] = "qatar_at_localhost";


$tdatajugadores[".strOriginalTableName"] = "jugadores";

	



$tdatajugadores[".showAddInPopup"] = false;

$tdatajugadores[".showEditInPopup"] = false;

$tdatajugadores[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatajugadores[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatajugadores[".listAjax"] = false;
//	temporary
$tdatajugadores[".listAjax"] = false;

	$tdatajugadores[".audit"] = false;

	$tdatajugadores[".locking"] = false;


$pages = $tdatajugadores[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatajugadores[".edit"] = true;
	$tdatajugadores[".afterEditAction"] = 1;
	$tdatajugadores[".closePopupAfterEdit"] = 1;
	$tdatajugadores[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdatajugadores[".add"] = true;
$tdatajugadores[".afterAddAction"] = 1;
$tdatajugadores[".closePopupAfterAdd"] = 1;
$tdatajugadores[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdatajugadores[".list"] = true;
}



$tdatajugadores[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatajugadores[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatajugadores[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatajugadores[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatajugadores[".printFriendly"] = true;
}



$tdatajugadores[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatajugadores[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatajugadores[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatajugadores[".isUseAjaxSuggest"] = true;

$tdatajugadores[".rowHighlite"] = true;





$tdatajugadores[".ajaxCodeSnippetAdded"] = false;

$tdatajugadores[".buttonsAdded"] = false;

$tdatajugadores[".addPageEvents"] = false;

// use timepicker for search panel
$tdatajugadores[".isUseTimeForSearch"] = false;


$tdatajugadores[".badgeColor"] = "9ACD32";


$tdatajugadores[".allSearchFields"] = array();
$tdatajugadores[".filterFields"] = array();
$tdatajugadores[".requiredSearchFields"] = array();

$tdatajugadores[".googleLikeFields"] = array();
$tdatajugadores[".googleLikeFields"][] = "Id";
$tdatajugadores[".googleLikeFields"][] = "Nombre y apellido";
$tdatajugadores[".googleLikeFields"][] = "Posicion";
$tdatajugadores[".googleLikeFields"][] = "Numero Camiseta";
$tdatajugadores[".googleLikeFields"][] = "Seleccion";



$tdatajugadores[".tableType"] = "list";

$tdatajugadores[".printerPageOrientation"] = 0;
$tdatajugadores[".nPrinterPageScale"] = 100;

$tdatajugadores[".nPrinterSplitRecords"] = 40;

$tdatajugadores[".geocodingEnabled"] = false;










$tdatajugadores[".pageSize"] = 20;

$tdatajugadores[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatajugadores[".strOrderBy"] = $tstrOrderBy;

$tdatajugadores[".orderindexes"] = array();


$tdatajugadores[".sqlHead"] = "SELECT Id,  	`Nombre y apellido`,  	Posicion,  	`Numero Camiseta`,  	Seleccion";
$tdatajugadores[".sqlFrom"] = "FROM jugadores";
$tdatajugadores[".sqlWhereExpr"] = "";
$tdatajugadores[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatajugadores[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatajugadores[".arrGroupsPerPage"] = $arrGPP;

$tdatajugadores[".highlightSearchResults"] = true;

$tableKeysjugadores = array();
$tableKeysjugadores[] = "Id";
$tdatajugadores[".Keys"] = $tableKeysjugadores;


$tdatajugadores[".hideMobileList"] = array();




//	Id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "Id";
	$fdata["GoodName"] = "Id";
	$fdata["ownerTable"] = "jugadores";
	$fdata["Label"] = GetFieldLabel("jugadores","Id");
	$fdata["FieldType"] = 3;

	
	
	
			

		$fdata["strField"] = "Id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatajugadores["Id"] = $fdata;
		$tdatajugadores[".searchableFields"][] = "Id";
//	Nombre y apellido
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "Nombre y apellido";
	$fdata["GoodName"] = "Nombre_y_apellido";
	$fdata["ownerTable"] = "jugadores";
	$fdata["Label"] = GetFieldLabel("jugadores","Nombre_y_apellido");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Nombre y apellido";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Nombre y apellido`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatajugadores["Nombre y apellido"] = $fdata;
		$tdatajugadores[".searchableFields"][] = "Nombre y apellido";
//	Posicion
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Posicion";
	$fdata["GoodName"] = "Posicion";
	$fdata["ownerTable"] = "jugadores";
	$fdata["Label"] = GetFieldLabel("jugadores","Posicion");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Posicion";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Posicion";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "posiciones";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Posiciones";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Posiciones";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatajugadores["Posicion"] = $fdata;
		$tdatajugadores[".searchableFields"][] = "Posicion";
//	Numero Camiseta
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Numero Camiseta";
	$fdata["GoodName"] = "Numero_Camiseta";
	$fdata["ownerTable"] = "jugadores";
	$fdata["Label"] = GetFieldLabel("jugadores","Numero_Camiseta");
	$fdata["FieldType"] = 3;

	
	
	
			

		$fdata["strField"] = "Numero Camiseta";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Numero Camiseta`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatajugadores["Numero Camiseta"] = $fdata;
		$tdatajugadores[".searchableFields"][] = "Numero Camiseta";
//	Seleccion
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Seleccion";
	$fdata["GoodName"] = "Seleccion";
	$fdata["ownerTable"] = "jugadores";
	$fdata["Label"] = GetFieldLabel("jugadores","Seleccion");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "Seleccion";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Seleccion";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "selecciones";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "Nombre";
	$edata["LinkFieldType"] = 0;
	$edata["DisplayField"] = "Nombre";

	

	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatajugadores["Seleccion"] = $fdata;
		$tdatajugadores[".searchableFields"][] = "Seleccion";


$tables_data["jugadores"]=&$tdatajugadores;
$field_labels["jugadores"] = &$fieldLabelsjugadores;
$fieldToolTips["jugadores"] = &$fieldToolTipsjugadores;
$placeHolders["jugadores"] = &$placeHoldersjugadores;
$page_titles["jugadores"] = &$pageTitlesjugadores;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["jugadores"] = array();

// tables which are master tables for current table (detail)
$masterTablesData["jugadores"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_jugadores()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "Id,  	`Nombre y apellido`,  	Posicion,  	`Numero Camiseta`,  	Seleccion";
$proto0["m_strFrom"] = "FROM jugadores";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "Id",
	"m_strTable" => "jugadores",
	"m_srcTableName" => "jugadores"
));

$proto6["m_sql"] = "Id";
$proto6["m_srcTableName"] = "jugadores";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "Nombre y apellido",
	"m_strTable" => "jugadores",
	"m_srcTableName" => "jugadores"
));

$proto8["m_sql"] = "`Nombre y apellido`";
$proto8["m_srcTableName"] = "jugadores";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Posicion",
	"m_strTable" => "jugadores",
	"m_srcTableName" => "jugadores"
));

$proto10["m_sql"] = "Posicion";
$proto10["m_srcTableName"] = "jugadores";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Numero Camiseta",
	"m_strTable" => "jugadores",
	"m_srcTableName" => "jugadores"
));

$proto12["m_sql"] = "`Numero Camiseta`";
$proto12["m_srcTableName"] = "jugadores";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Seleccion",
	"m_strTable" => "jugadores",
	"m_srcTableName" => "jugadores"
));

$proto14["m_sql"] = "Seleccion";
$proto14["m_srcTableName"] = "jugadores";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto16=array();
$proto16["m_link"] = "SQLL_MAIN";
			$proto17=array();
$proto17["m_strName"] = "jugadores";
$proto17["m_srcTableName"] = "jugadores";
$proto17["m_columns"] = array();
$proto17["m_columns"][] = "Id";
$proto17["m_columns"][] = "Nombre y apellido";
$proto17["m_columns"][] = "Posicion";
$proto17["m_columns"][] = "Numero Camiseta";
$proto17["m_columns"][] = "Seleccion";
$obj = new SQLTable($proto17);

$proto16["m_table"] = $obj;
$proto16["m_sql"] = "jugadores";
$proto16["m_alias"] = "";
$proto16["m_srcTableName"] = "jugadores";
$proto18=array();
$proto18["m_sql"] = "";
$proto18["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto18["m_column"]=$obj;
$proto18["m_contained"] = array();
$proto18["m_strCase"] = "";
$proto18["m_havingmode"] = false;
$proto18["m_inBrackets"] = false;
$proto18["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto18);

$proto16["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto16);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="jugadores";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_jugadores = createSqlQuery_jugadores();


	
		;

					

$tdatajugadores[".sqlquery"] = $queryData_jugadores;



$tableEvents["jugadores"] = new eventsBase;
$tdatajugadores[".hasEvents"] = false;

?>